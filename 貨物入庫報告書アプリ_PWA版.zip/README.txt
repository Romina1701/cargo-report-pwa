貨物入庫報告書アプリ PWA版

【GitHubへアップロードするファイル】
・index.html
・manifest.json
・sw.js
・icons フォルダ
  ・icon-192.png
  ・icon-512.png

上記を cargo-report-app リポジトリの一番上に置いてください。

【iPhoneへの追加】
1. Safariで公開URLを開く
2. 共有ボタン
3. 「ホーム画面に追加」
4. 追加したアイコンから起動

【Androidへの追加】
1. Chromeで公開URLを開く
2. メニュー
3. 「アプリをインストール」または「ホーム画面に追加」

【セキュリティ仕様】
・入力情報のlocalStorage保存なし
・自動下書き保存なし
・サーバーへの入力データ送信なし
・PDF作成は端末側で実行
・QRコード生成はQuickChartへの通信を使用するため、QR生成時は通信が必要な場合があります
・html2canvas、jsPDFは初回読み込み後にService Workerのキャッシュ対象になります

【更新時】
sw.js の CACHE_NAME を v2、v3 のように変更すると更新が反映されやすくなります。
